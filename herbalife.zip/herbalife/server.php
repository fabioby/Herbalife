<?php
	if(isset($_POST['getData'])){
		$sql = $_POST['sql'];
		$data = getData($sql);
		echo json_encode($data);
	}
	if(isset($_POST['submit_order'])){
		$sql = $_POST['submit_order'];
		insertData(json_decode($sql));
	}
	if(isset($_GET['sendMail'])){
		$email = $_GET['email'];
		$msg = $_GET['msg'];
		sendMail($email,$msg);
	}


	function getData($sql) {
		//$db = mysqli_connect('localhost','obyartco_admin','fabian156380','obyartco_db');
		$db = mysqli_connect('localhost','root','','herbalife');
		mysqli_set_charset($db,"utf8");
		$result = mysqli_query($db,$sql);
		$container = [];
		if ($result->num_rows > 0){
			while($data = mysqli_fetch_assoc($result)){
				$container[] = $data;
			}
			return $container;
		}
		//mysqli_close($db);
	}
	function insertData($sql) {
		//$db = mysqli_connect('localhost','obyartco_admin','fabian156380','obyartco_db');
		$db = mysqli_connect('localhost','root','','herbalife');
		$datetime = date('Y-m-d H:i:s');
		if (mysqli_query($db, $sql.",'".$datetime."')")) {
			echo "New record created successfully";
		  } else {
			echo "Error: " . $sql . "<br>" . mysqli_error($db);
		  }
		//mysqli_close($db);
	}
	function sendMail($email,$msg) {
		mail($email,"Rendelését rögzítettük",$msg);
		mail("fabian.obersovszky@gmail.com","Új Herbalife rendelés!",$msg);
	}
?>