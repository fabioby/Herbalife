var vue = new Vue({
	el: '#vue',
	data: {
		products: [],
		cart: [],
		price: 0,
		name:'',
		email:'',
		phone:'',
		city:'',
		postcode:'',
		street:'',
		note:'',
		take:'',
		payment:'',
	},
	created(){
		//this.products.push({id:"1", name:"test", type:"test", price:"test", img:"test", description:"test"})
		this.fillArray("SELECT * FROM products");
	
		if (localStorage.getItem("cart") === null) {
			localStorage.setItem("cart",JSON.stringify([]))
			//alert("cart created")
		} else {
			this.cart = JSON.parse(localStorage.getItem("cart"));
		}
	},
	methods:{
		fillArray(sql){
			var data = getData(sql);
			this.products = [];
			data.forEach(item => {
				//alert(item+"")
				this.products.push({id:item['id'], name:item['name'], type:item['type'], price:item['price'], img:item['img'], description:item['description']})
			});
		},
		sortArray(){
			var type = $("#select_type").val();
			var order = $("#select_order").val();
			var search = $("#search").val()+"%";
			if(type == "*")
			this.fillArray("SELECT * FROM products WHERE name LIKE '%"+search+"' ORDER BY "+order);
			else {
				this.fillArray("SELECT * FROM products WHERE name LIKE '%"+search+"' AND type = '"+type+"' ORDER BY "+order);
			}
		},
		addToCart(e){
			var id = e.target.getAttribute('data-id');
			var isInCart = false;

			this.cart.forEach(item => {
				if(item.id == id){
					isInCart = true;
					item.quantity++;
				}	
			})

			if(isInCart == false){			
				this.products.forEach(item => {
					if(item.id == id){
						this.cart.push({id:item.id, name:item.name, type:item.type, price:item.price, quantity:1})
					}
				})
			}
			localStorage.setItem('cart', JSON.stringify(this.cart));
			this.calcPrice();
		},
		clearCart(){
			toggleModal("modal_cart");
			this.cart = [];
			this.price = 0;	
			localStorage.setItem("cart",JSON.stringify([]))
		},
		removeFromCart(id){
			for (i=0; i < this.cart.length; i++) {
				if(this.cart[i].id == id){
					this.cart.splice(i, 1);
				}
			}
			if (this.cart.length === 0){
				toggleModal("modal_cart");
			}
			localStorage.setItem("cart",JSON.stringify(this.cart));
			this.calcPrice();
		},
		changeQuantity(e){
			var id = e.target.getAttribute('data-id');
			var value = e.target.value;

			this.cart.forEach(item => {
				if(item.id == id){
					if(value > 0){
						item.quantity = value;
						localStorage.setItem('cart', JSON.stringify(this.cart));
					} else {
						this.removeFromCart(item.id);
					}
				}
			})
			this.calcPrice();
		},
		onChange(event){
			if(event.target.value == 1){
				this.payment = 1;
			}
		},
		calcPrice(){
			this.price = 0;
			this.cart.forEach(item => {
				this.price += item.price * item.quantity;
			})
		},
		setOrder(){
			var address = this.city+" "+this.postcode+" "+this.street;
			var take = "";
			var payment = "";
			
			if(this.takeover == 0){
				take = "personal";
			} else {
				take = "post"
			}
			if(this.payment == 0){
				payment = "cash"
			} else {
				payment = "bank"
			}
			
			var msg = "Tisztelt "+this.name+"\nRendelését a rendszer rögzitette.\n\nRendelt termékek:\n";
			
			this.cart.forEach(item => {
				msg += item.name+" x"+item.quantity+" : "+item.price*item.quantity+" Ft\n";
				var p_id = item.id;
				var quantity = item.quantity;
				insertData("INSERT INTO orders (name,email,phone,address,note,payment,ship,p_id,quantity,datetime) VALUES('"+this.name+"','"+this.email+"','"+this.phone+"','"+address+"','"+this.note+"','"+payment+"','"+take+"','"+p_id+"','"+quantity+"'");
			})
			msg += "ÖSSZESEN: "+this.price+" Ft\n\n";

			if(this.take == 0){
				msg += "Személyes átvétel itt: Budapest, 1087 Jobbágy utca 5-9\nSikeres megrendelést követően, rendelését feldolgozzuk, majd értesítjük annak elérhetőségét személyes átvételre. Időtartama körülbelül 1 nap."
			} 
			else if(this.take == 1){
				msg += "Sikeres megrendelés és átutalást követően, a megrendelt termékeket, az ön által kiválasztott módon, postai úton(DHL) küldjük el önhöz.\nBanki átutalás ide:\nBank: OTP Bank\nSzámlaszám: 11773078-00571645\nvagy\nBank: Revolut\nSzámlaszám: 12001008-01644328–00400008\nKözlemény: 73443727\n\nObersovszky Fabian Tamás\nfabian.obersovszky@gmail.com\n+36 70 603 6510"
			}
			
			sendMail(this.email,msg);
			alert("Sikeres rendelés! Minden szükséges információt elküldtünk az ön által megadott email címre: "+this.email);
			toggleModal("modal_checkout");
		},
		toggleFilter(){
			$("#filters").fadeToggle(150);
		}
	}
})
//toggleModal("modal_cart")

function getData(sql){
	var result;
    $.ajax({
		url: 'server.php',
	    type: 'POST',
		async: false,
	    dataType: 'JSON',
	    data: {
			'getData': 1,
			'sql': sql
		},
	    success: function(response){
			//alert("1")
			result = response;
		},
		error: function (xhr, ajaxOptions, thrownError) {
			alert(xhr.status);
			alert(thrownError);
		}
	});
	/*
	$.ajax({
		type: "GET",
		url: 'server.php',
		dataType: 'json',
		data: {getData: sql},
	    success: function(response){
			result = response;
		},
		error: function (xhr, ajaxOptions, thrownError) {
			alert(xhr.status);
			alert(thrownError);
		}
		
	});
	*/
	return result;  
}
function insertData(sql){
	//alert("succes")
    $.ajax({
	    url: 'server.php',
	    type: 'POST',
	    dataType: 'JSON',
		async:false,
		data: {submit_order: JSON.stringify(sql)},
	    success: function(response){
			alert("succes")
		}
	});
}
function sendMail(email,msg){
	$.ajax({
		url: 'server.php',
		type: 'GET',
		data: {
			   'sendMail': 1,
			   'email': email,
			   'msg': msg,
		},
		success: function(response){
			   //alert();
		}
 });
 window.vue.clearCart();
}
//sendMail("fabian.obersovszky@gmail.com","szia")

function toggleModal(modal_id){
	$("#"+modal_id).fadeToggle(200)

	var width = $("#"+modal_id+" .modal_window").width();
	var height = $("#"+modal_id+" .modal_window").height();
	var sw = $(window).width();
	var sh = $(window).height();
	$("#"+modal_id+" .modal_window").css("left",(sw-width)/2);
	$("#"+modal_id+" .modal_window").css("top",(sh-height)/2);
}



$("#select_type").change(function() {
	$("#search").val("");
	window.vue.sortArray();
});
$("#select_order").change(function() {
	window.vue.sortArray();
});
$("#search").change(function() {
	$("#select_type").prop("selectedIndex", 0);
	window.vue.sortArray();
});
/*
$('.circle').animate({transform: 1},
	{duration:5000,easing:'linear',
	step: function(now, fx) {
	$(this).css('transform','scale('+now+')')}
	})*/


if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) 
|| /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) { 

	setSize()
	
}


function setSize(){
	var tags = ["h1","h2","h3","h4","h5","h6","p","span","input","select","button","i","label","div"]

	tags.forEach(item => {
		setContentSize(item);
	})
}
//setSize()

function setContentSize(tag){
	var list = document.getElementsByTagName(tag);
	var num = parseFloat($(list).css("fontSize")) * (100 / document.documentElement.clientWidth);
	if(num > 0){
		$(list).css("fontSize", num+2+"vw");
	}
}