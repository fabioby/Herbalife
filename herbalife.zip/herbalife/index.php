<!DOCTYPE html>
<html>
	<?php include 'head.php'; ?>
	<body>
		<div id="vue">
			<header>
				<div>	
					<div>
						<div id="filters">
							<select id="select_type">
								<option value="*" selected>Minden termék</option>	
								<?php
									$data = getData("SELECT DISTINCT type FROM products");
									foreach ($data as $value) {
										?>
								<option value="<?php echo $value['type'] ?>" <?php if(isset($_GET['select_type']) && $_GET['select_type'] == $value['type']) echo 'selected' ?>>
								<?php echo $value['type'] ?></option>
								<?php } ?>
							</select>
							<select id="select_order">
								<option value="id ASC" selected>Rendezés: Alapértelmezett</option>
								<option value="price ASC" <?php if(isset($_GET['select_order']) && $_GET['select_order'] == "price ASC") echo 'selected' ?>>Rendezés: Ár növekvő</option>
								<option value="price DESC" <?php if(isset($_GET['select_order']) && $_GET['select_order'] == "price DESC") echo 'selected' ?>>Rendezés: Ár csökkenő</option>
							</select>
							<input class="search" type="text" id="search" placeholder="Keresés..">
						</div>
						<div v-on:click="toggleFilter()">
							<i class="fa fa-filter"></i>
							<span>Szűrés</span>
						</div>
					</div>
					<div>
						<div>
							<span class="circle" onclick="toggleModal('modal_cart')">{{this.cart.length}}</span>
							<a href="#" onclick="toggleModal('modal_cart')">
								<i class="glyphicon glyphicon-shopping-cart"></i>
								<span>Kosár</span>
							</a>
						</div>
					</div>
				</div>
			</header>

			<div class="index">
				<div class="product" v-for="item in products">
					<img :src="'files/images/products/' + item.img">
					<h4>{{item.name}}</h4>
					<p>{{item.description}}</p>
					<p class="price">{{item.price}} Ft</p>
					<div class="button" v-on:click="addToCart" :data-id="item.id">Kosárba</div>
				</div>
			</div>

			<?php include 'footer.php'; ?>
		</div>
		<script src="files/js/js.js"></script>
	</body>
</html>