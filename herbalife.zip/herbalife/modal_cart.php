<div class="modal" id="modal_cart" >
	<div class="modal_bg" onclick="toggleModal('modal_cart')"></div>
	<div class="modal_window">
		<div class="modal_header">
			<h3>Kosár</h3>
			<i class="fa fa-times" aria-hidden="true" onclick="toggleModal('modal_cart')"></i>
		</div>
		<div class="modal_body">
			<div class="cart">
				<div v-if="cart.length > 0" v-for="item in cart">
					<div class="sss">{{ item.name }}</div>
					<div><input type="number" :value="item.quantity" :data-id="item.id" @change="changeQuantity"
					min="0"></div>
					<div>{{ item.price * item.quantity }} Ft</div>
					<div v-on:click="removeFromCart(item.id)">&times</div>
				</div>
				<h2 v-if="cart.length === 0">A kosár üres</h2>
			</div>
		</div>
		<div class="modal_footer" v-if="cart.length > 0">
			<span>Összesen: {{price}} Ft</span>
			<button class="button" v-on:click="clearCart()">KIÜRITÉS</button>
			<button class="button" onclick="toggleModal('modal_cart'),toggleModal('modal_checkout')">MEGRENDELÉS</button>
		</div>
	</div>
</div>


<div class="modal" id="modal_checkout" >
	<div class="modal_bg" onclick="toggleModal('modal_checkout')"></div>
	<div class="modal_window">
		<div class="modal_header">
			<h3>Rendelés leadás</h3>
			<i class="fa fa-times" aria-hidden="true" onclick="toggleModal('modal_checkout')"></i>
		</div>
		<div class="modal_body">
			<div class="checkout">
				<form method="POST" @submit.prevent="setOrder">
					<p>Kosárban lévő termékek megrendelése</p>
					<label>Személyes adatok</label>
					<input class="field" type="text" name="name" v-model="name" placeholder="Név *" required>
					<input class="field" type="email" name="email" v-model="email" placeholder="Email cím *" required>
					<input class="field" type="text" name="phone" v-model="phone" placeholder="Telefonszám (futárnak)">
					
					<label>Szállítási addatok</label>
					<select class="field">
						<option>Magyarország</option>
					</select>
					<input class="field" type="text" name="city" v-model="city" placeholder="Város *" required>
					<input class="field" type="text" name="postcode" v-model="postcode" placeholder="Irányitószám *" required>
					<input class="field" type="text" name="street" v-model="street" placeholder="Utca és hászszám *" required>
					<textarea class="field" name="note" v-model="note" placeholder="Megjegyzés a futárnak"></textarea>
					
					<select class="field" v-model="take" v-on:change="onChange($event)" required>
						<option disabled value="">Kérlek válasz szállítási módot</option>
						<option value="0">Személyes átvétel (Budapest, 1087 Jobbágy útca 5b)</option>
						<option value="1">Postai úton DHL (díjmentes szállítás)</option>
					</select>
					<select class="field" v-model="payment" required>
						<option disabled value="">Kérlek válassz fizetési módot</option>
						<option value="0" :disabled="take==1">Készpénzes fizetés (Személyes átvétel esetén)</option>
						<option value="1">Banki átutalás</option>
					</select>
					<p v-if="take==0 && take!=''">
						Személyes átvétel itt: <b>Budapest, 1087 Jobbágy utca 5-9</b><br>
						Sikeres megrendelést követően, rendelését feldolgozzuk, majd értesítjük annak elérhetőségét személyes átvételre. Időtartama körülbelül 1 nap.
					</p>

					<p v-if="take==1">
						Sikeres megrendelés és átutalást követően, a megrendelt termékeket, az ön által kiválasztott módon, postai úton(DHL) küldjük el önhöz.<br>
						Az átutaláshoz (OTP/Revolut) szükséges adatokat az ön által megadott email címre küldjük el.
					</p>
					<p>Minden szükséges információt elküldünk az ön által megadott email címre: {{email}}</p>
					<input class="button" type="submit" name="submit" value="Megrendelés">
				</form>
			</div>
		</div>
		<div class="modal_footer">
			<button class="button" onclick="toggleModal('modal_cart'),toggleModal('modal_checkout')">VISSZA A KOSÁRHOZ</button>
		</div>
	</div>
</div>