<!DOCTYPE html>
<html>
	<?php include 'head.php'; ?>
	<body>

		<header>
			<div>	
				<div>
					<button onclick="toggleModal('modal_product')">New Product</button>
				</div>
				<div>
					<a href="?logout"></i> Logout</a>	
				</div>
			</div>
		</header>
		
		<div class="admin">
			<?php
				$products = $server->getProducts();
				foreach ($products as $key => $value) {
			?>
			<div class="list_for" id="f<?php $value->getId() ?>">
				<div><h3><?php $value->getName() ?></h3></div>
				<div>
					<button class="button" id="button_edit" data-id="<?php $value->getId() ?>">EDIT</button>
					<button class="button" id="button_delete" data-id="<?php $value->getId() ?>">DELETE</button>
				</div>
			</div>
			<?php } ?>
		</div>

		<div class="modal" id="modal_product" >
			<div class="modal_bg" onclick="toggleModal('modal_product')"></div>
			<div class="modal_window">
				<div class="modal_header">
					<h3>ÚJ TERMÉK</h3>
					<i class="fa fa-times" aria-hidden="true" onclick="toggleModal('modal_product')"></i>
				</div>
				<div class="modal_body">
					<form method="post" action="server.php" enctype="multipart/form-data" onsubmit="//return false">
						<input class="field" type="text" name="name" placeholder="Megnevezés *" required>
						<input class="field" type="text" name="description" placeholder="Leírás" required>
						<input class="field" type="text" name="price" placeholder="Ár *" required>
						<select name="select_type">
							<option value="Shake">Shake</option>
							<option value="Magas fehérjetartalmú snackek">Magas fehérjetartalmú snackek</option>
							<option value="Alacsony kalóriatartalmú italok">Alacsony kalóriatartalmú italok</option>
							<option value="Rostok">Rostok</option>
							<option value="Herbal Aloe">Herbal Aloe</option>
						</select>
						<input class="field" type="file" name="file" required>
						<input class="button" type="submit" name="submit_add">
					</form>
				</div>
			</div>
		</div>

		<script src="files/js/js.js"></script>
	</body>
</html>