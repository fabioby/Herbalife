<footer>
	<div>
		<a href="https://www.facebook.com/fabian.obersovszky"><i class="fa fa-facebook-square"></i></a>
		<a href="tel:06706036510"><i class="fa fa-phone" style="color:white;font-size:2vw"></i></a>
		<!--<a href="https://www.facebook.com/fabian.obersovszky">© Herbalife Theme. All Rights Reserved.<br>Designed by Fabian Obersovszky</a>-->
	</div>
</footer>


<?php include 'modal_cart.php'; ?>